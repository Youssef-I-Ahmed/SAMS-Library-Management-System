# SAMS legacy raw-data handoff

This package is **RAW and UNCLEANED**. It is an extraction-only handoff from the legacy aLIS library system to the Data Analysis team.

- Exact source database: `Y:\Courses\sams\aLIS\slis.db`
- Technology: Sybase SQL Anywhere / Adaptive Server Anywhere 8; database header version `8.0.0.2213`.
- Extraction date/time: 2026-10-07T02:17:29+03:00 (Africa/Cairo, UTC+03:00).
- Decoded source: `Y:\Courses\sams\Ddrive\_analysis\sams\04c9fb714000\records.json`; original table and column names/order come from the companion `schema.json`.

## Package scope

The inspected schema contains 120 application base tables (creator ID 101). All 40 populated application tables are exported separately; all 80 empty application tables appear in MANIFEST.csv without a table CSV. Legacy PowerBuilder `pbcat*` application metadata is included. System catalogs, compatibility tables, replication support tables, system views and temporary objects are excluded. Creator 1 also owns separate DBA-level PowerBuilder pbcat* metadata tables; those are excluded as system/tooling metadata. The exported pbcat* files are the application-owned (creator 101) tables with those original names. Excluded owner IDs are 0, 1, 3 and 4. No application table was excluded because of its name or purpose: existing STATISTICS data, test-looking tables, users, configuration and relationship tables remain in scope.

Each table CSV contains its original columns only, in legacy schema order, and all decoded rows in artifact order. Forensic row offsets are not added as business columns. No sorting, filtering, cleaning, aggregation, deduplication, text normalization, spelling correction, missing-value filling or relationship repair was performed. Existing columns with names such as PURE_* are original stored fields, not transformations made for this handoff. No analytical master dataset, EDA, derived analytical metrics or PostgreSQL migration was created.

## CSV transport and missing values

Files use UTF-8 without a byte-order mark, comma delimiters, a header row, CRLF record separators and double-quoted fields. Embedded quotes are doubled; embedded commas, line breaks and whitespace are preserved. Count records with a CSV parser, not by counting lines.

The exact field value `\N` represents source NULL. This marker was checked against every non-NULL source string and has no collisions. An empty quoted field (`""`) represents an actual empty string and is distinct from NULL. Configure importers to recognize only the documented NULL marker; do not infer missing values from other strings. This is a transport encoding of NULL, not an imputed source value.

Strings, including Arabic and English, are copied verbatim from the existing decoded artifact. That artifact used Windows CP1256 for legacy text; readable Arabic and English samples were inspected, and the export was verified field-for-field after UTF-8 CSV rereading. No Unicode replacement characters occur in the exported source strings. The legacy collation label reported by the earlier forensic work is not treated as an instruction to reinterpret the Arabic bytes.

Native date values that were not reliably decoded remain a JSON object within their original column, for example `{"date_raw":"01020304"}` (illustrative bytes). The hexadecimal string preserves the decoder's four source bytes in stored order; it is not an interpreted date. Affected columns: `BOOK.ENTER_DATE`, `STATISTICS.STATISTIC_DAY`. NULL dates remain `\N`. No dates were guessed or reformatted.

Original IDs and codes are retained. Decoded integers are written as full decimal text without scientific notation, rounding or floating-point conversion; text codes retain leading zeros, whitespace and case. Import identifier/code columns as text when using software that would otherwise auto-convert them. CSV itself does not carry column types. Unquoted/quoted status does not imply numeric typing here because all fields are quoted.

## Basic table relationships

These are legacy linking fields for navigation; their presence is not a claim that every reference has a matching record or that database constraints enforce every relationship.

- `BOOK.BOOK_CODE` is the catalog identifier used by `COPIES_VOLUMES.BOOK_CODE` and the book linking tables. `COPIES_VOLUMES.GENERAL_CODE` identifies physical-copy records.
- `EDITOR_BOOK` links `BOOK_CODE` to `EDITOR.EDIT_CODE` through `EDIT_CODE` and preserves the stored contributor-role fields.
- `PUBL_BOOK` links `BOOK_CODE` to `PUBLISHER.PUBL_CODE` through `PUBL_CODE` and retains publication detail fields.
- `BOOK_SUBJECT` links `BOOK_CODE` to `SUBJECT.SUBJECT_CODE` through `SUBJECT_CODE`.
- `SERIAL_BOOK` links `BOOK_CODE` to `SERIALS.SER_CODE` through `SER_CODE` and retains `SERIAL_NUM`.
- `BOOK_OTHER_TITLES` holds additional title fields associated with `BOOK_CODE`.
- `BORROWING` and `BORROWING_HISTORY` contain `BORROWER_CODE` and `GENERAL_CODE` fields for borrower/copy references; `RESERVATION` contains borrower, book, volume and copy reference fields. These three tables are empty in this decoded source and are documented only in the manifest.
- Lookup tables such as `BOOK_TYPE`, `RECORD_TYPE`, `LANGUAGE`, `STATUS`, `COUNTRY` and `REGION` retain their original codes and labels.

IDs and linking tables were intentionally preserved. Missing values, duplicates, suspicious records, orphan references and any other data-quality issues were intentionally NOT corrected. Decisions about cleaning, EDA, deduplication, missing values and analytical preparation belong to the Data Analysis team.

## Extraction validation and limits

Every exported CSV was reread with a CSV parser. Each table's row count matches the decoded source and stored catalog count, and every field matches its documented reversible serialization. All 120 application tables were accounted for. Export errors: none. Count mismatches: none. SOURCE_INTEGRITY.md records source/artifact provenance and read-only checks.

This is an export of previously decoded offline forensic rows, not a vendor-engine query or recovery. Transaction-log consistency, index validity, unreferenced/deleted/slack storage and semantic interpretation of the source data are not certified. Raw date bytes are preserved as described above. No original database engine, application executable, recovery process or migration was run for this handoff.
