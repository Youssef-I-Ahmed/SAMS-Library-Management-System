# Source integrity

- Exact source path: `Y:\Courses\sams\aLIS\slis.db`
- Source file size before and after export: 98566144 bytes.
- Source SHA-256 before and after export: `04c9fb71400033c3bb2545de00aed482347b21b23f55d79de614d8fbb90c4a68`.
- Detected technology/version: Sybase SQL Anywhere / Adaptive Server Anywhere 8, header version `8.0.0.2213`, confirmed by a read-only byte read at offset `0x168`.
- Extraction date/time: 2026-10-07T02:17:29+03:00 (Africa/Cairo, UTC+03:00).
- Total BOOK rows: 2843; CSV rows: 2843.
- BOOK rows where BOOK_TYPE equals the exact string 'B': 2837. This is the requested source identity check; BOOK.csv contains all BOOK rows.
- COPIES_VOLUMES rows: 4832; CSV rows: 4832.
- Application tables: 120; populated/exported: 40; empty/manifest only: 80.

## Read-only confirmation

The original source database was not modified. It was opened only in binary read mode for hashing and header verification. SHA-256, file size and last-write timestamp were identical before and after export. Last-write timestamp (nanoseconds since Unix epoch) before and after: `1136070856000000000`. No original legacy evidence file was written, modified, recovered or replaced. All generated files are under `Y:\Courses\sams\Ddrive\_analysis\output`. No SQL Anywhere engine or legacy executable was launched, and no SAMS PostgreSQL migration was performed.

## Decoded artifact provenance

CSV row values came exclusively from `Y:\Courses\sams\Ddrive\_analysis\sams\04c9fb714000\records.json`. Column names and order and stored table counts came from `Y:\Courses\sams\Ddrive\_analysis\sams\04c9fb714000\schema.json`. The prior provenance entry in `Y:\Courses\sams\Ddrive\_analysis\sams\new_database_summary.json` identifies the exact source path and the same full SHA-256 above. Its application counts match the decoded artifact and stored schema counts. The companion `errors.json` is an empty array. These three artifacts were verified unchanged during export.

- `Y:\Courses\sams\Ddrive\_analysis\sams\04c9fb714000\records.json`: SHA-256 `d1f2ceefd40f1fce86d5a53cf36f79a55bb7417f984f5cd1c0a550eb6991bd47`; 12271886 bytes.
- `Y:\Courses\sams\Ddrive\_analysis\sams\04c9fb714000\schema.json`: SHA-256 `104b4c4d58120905d5a4e7539baa9c754d8b48bf623988861bc11723ede2e4ea`; 449093 bytes.
- `Y:\Courses\sams\Ddrive\_analysis\sams\04c9fb714000\errors.json`: SHA-256 `4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945`; 2 bytes.

## Validation

All 40 populated-table CSV row counts match the decoded source; all 120 decoded application counts match stored catalog metadata. Original column spelling/case/order and every serialized field were checked after CSV rereading. IDs and relationship fields pass the same full-field and reversible-type checks, without floating-point conversion. UTF-8 text round-trips exactly; Arabic and English sample titles were inspected. No export failures, missing decoded application tables, field mismatches or row-count mismatches occurred. MANIFEST.csv records decoded source, exported and stored catalog row counts per table, including empty tables.

## Extraction limitations

The existing artifact was produced by an offline read-only parser, not vendor-engine SELECT queries. This handoff does not certify engine/transaction/index consistency or completeness of deleted/unreferenced storage. Windows CP1256 is the prior text-decoding choice; no further text conversion or normalization was applied except UTF-8 encoding. Native dates in BOOK.ENTER_DATE and STATISTICS.STATISTIC_DAY remain their original date_raw hexadecimal objects, serialized as JSON in the corresponding CSV fields. Their calendar meaning has not been guessed. CSV NULL is represented by the collision-checked \N marker, distinct from empty text. These representation limitations are disclosed in README.md and relevant manifest notes.
